#define MAKE_NOCOPY(classname)                    \
    private:                                      \
        classname(const classname&) = delete;     \
        void operator=(const classname&) = delete;

// 2. �̱����� ����� ��ũ��
#define MAKE_SINGLETON(classname)                           \
    private:                                                \
        classname() {}                                      \
        MAKE_NOCOPY(classname)                              \
    public:                                                 \
        static classname& getInstance()                     \
        {                                                   \
            static classname instance;                      \
            return instance;                                \
        }