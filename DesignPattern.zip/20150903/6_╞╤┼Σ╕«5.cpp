// 6_���丮3
#include <vector>
#include <iostream>
using namespace std;

class Shape
{
public:
    virtual void draw() { cout << "Shape draw" << endl; }
};

#include <map>
#include "Helper.h"
class ShapeFactory
{
    MAKE_SINGLETON(ShapeFactory)

        typedef Shape*(*CREATOR)();
    map<int, CREATOR> create_map;
public:
    void registerShape(int type, CREATOR creator)
    {
        create_map[type] = creator;
    }

    Shape* createShape(int type)
    {
        Shape* p = 0;
        if (create_map[type] != 0)
            p = create_map[type]();

        return p;
    }
};

// ��ǰ�� ���忡 �ڵ����� ����ϴ� Ŭ����
class RegisterShape
{
public:
    RegisterShape(int type, Shape*(*f)())
    {
        ShapeFactory& factory = ShapeFactory::getInstance();
        factory.registerShape(type, f);
    }
};

// ��ǰ�� �ڵ����� ���忡 ������ִ� ��ũ�θ� ��������.
#define DECLARE_REGISTER_SHAPE()                    \
    public:                                         \
        static Shape* createObject();               \
        static RegisterShape rs;                    

#define IMPLEMENT_REGISTER_SHAPE(classname, type)               \
    Shape* classname::createObject() { return new classname; }  \
    RegisterShape classname::rs(type, &classname::createObject);

class Rect : public Shape
{
public:
    void draw() { cout << "Rect draw" << endl; }
    DECLARE_REGISTER_SHAPE()
};

class Circle : public Shape
{
public:
    void draw() { cout << "Circle draw" << endl; }
    DECLARE_REGISTER_SHAPE()
};

// http://d.pr/n/13aqe
class Triangle : public Shape
{
public:
    void draw() { cout << "Triangle" << endl; }

    DECLARE_REGISTER_SHAPE()
};

IMPLEMENT_REGISTER_SHAPE(Rect, 1)
IMPLEMENT_REGISTER_SHAPE(Circle, 2)
IMPLEMENT_REGISTER_SHAPE(Triangle, 3)

int main()
{
    vector<Shape*> v;
    ShapeFactory& factory = ShapeFactory::getInstance();

    while (1)
    {
        int cmd;
        cin >> cmd;

        // ��ü�� ������ OCP�� �����ϰ� �� �� ���°�
        if (cmd > 0 && cmd < 5)
        {
            Shape* p = factory.createShape(cmd);
            if (p != 0)
                v.push_back(p);
        }
        else if (cmd == 9)
        {
            for (int i = 0; i < v.size(); ++i)
                v[i]->draw();
        }
    }

}