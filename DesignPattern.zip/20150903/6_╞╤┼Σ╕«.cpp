// http://d.pr/n/190tn

#include <vector>
#include <iostream>
using namespace std;

class Shape
{
public:
    virtual void draw() { cout << "Shape draw" << endl; }
};

class Rect : public Shape
{
public:
    void draw() { cout << "Rect draw" << endl; }
};

class Circle : public Shape
{
public:
    void draw() { cout << "Circle draw" << endl; }
};

int main()
{
    vector<Shape*> v;

    while (1)
    {
        int cmd;
        cin >> cmd;

        // ��ü�� ������ OCP�� �����ϰ� �� �� ���°�
        if      (cmd == 1) v.push_back(new Rect);
        else if (cmd == 2) v.push_back(new Circle);
        else if (cmd == 9)
        {
            for (int i = 0; i < v.size(); ++i)
                v[i]->draw();
        }
    }

}