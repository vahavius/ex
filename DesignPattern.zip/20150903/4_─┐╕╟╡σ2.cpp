// 4_Ŀ�ǵ�
// http://d.pr/n/D9AT
#include <vector>
#include <iostream>
using namespace std;

class Shape
{
public:
    virtual void draw() { cout << "Shape draw" << endl; }
};

class Rect : public Shape
{
public:
    void draw() { cout << "Rect draw" << endl; }
};

class Circle : public Shape
{
public:
    void draw() { cout << "Circle draw" << endl; }
};

// ��� ������ ��üȭ�Ѵ�.
struct ICommand
{
    virtual void execute() = 0;
    virtual bool canUndo() { return false; }
    virtual void undo()    {}

    virtual ~ICommand() {}
};

class AddCommand : public ICommand
{
    vector<Shape*>& v;
public:
    AddCommand(vector<Shape*>& p) : v(p) {}

    bool canUndo() { return true; }
    void undo()
    {
        Shape* p = v.back();
        v.pop_back();

        delete p;
    }

    virtual Shape* createShape() = 0;
    void execute()
    {
        v.push_back(createShape());
    }
};

// Factory Method : template method �� ����ε�, �ڽ��� �������ϴ�
// �����Լ��� �˰������� ������ �ƴ� ��ü�� �����϶�!!
// http://d.pr/n/11A3d
class AddRectCommand : public AddCommand
{
public:
    AddRectCommand(vector<Shape*>& p) : AddCommand(p) {}
    Shape* createShape() { return new Rect; }
};

class AddCircleCommand : public AddCommand
{
public:
    AddCircleCommand(vector<Shape*>& p) : AddCommand(p) {}
    Shape* createShape() { return new Circle; }
};

class DrawCommand : public ICommand
{
    vector<Shape*>& v;
public:
    DrawCommand(vector<Shape*>& p) : v(p) {}

    void execute()
    {
        for (int i = 0; i < v.size(); ++i)
            v[i]->draw();
    }

};

#include <vector>
// ���� ������ ���� ��ũ�� ���ɵ� ���� �� �ִ�.
// Composite Pattern
class MacroCommand : public ICommand
{
    vector<ICommand*> v;   // ���� ���ɵ�
public:
    void addCommand(ICommand* p) { v.push_back(p); }

    void execute()
    {
        for (int i = 0; i < v.size(); ++i)
            v[i]->execute();
    }
};

#include <stack>
int main()
{
    vector<Shape*> v;
       
    MacroCommand mc;
    mc.addCommand(new AddRectCommand(v));
    mc.addCommand(new AddCircleCommand(v));
    mc.addCommand(new DrawCommand(v));
    mc.execute();


    stack<ICommand*> undo;
    stack<ICommand*> redo;      // 1.
    while (1)
    {
        ICommand* command = 0;

        int cmd;
        cin >> cmd;

        if (cmd == 1)      command = new AddRectCommand(v);
        else if (cmd == 2) command = new AddCircleCommand(v);
        else if (cmd == 9) command = new DrawCommand(v);
        else if (cmd == 8)
        {
            command = redo.top();       // 3.
            redo.pop();
        }
        else if (cmd == 0)
        {
            command = undo.top();
            undo.pop();

            command->undo();

            redo.push(command);         // 2.
            command = 0;
        }
        if (command != 0)
        {
            command->execute();
            if (command->canUndo())
                undo.push(command);
        }

    }
}