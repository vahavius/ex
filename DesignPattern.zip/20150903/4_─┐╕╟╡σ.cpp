// 4_Ŀ�ǵ�
// ������ ��ü�� �߻�ȭ�ϴ� ����
//  NSUndoManager

// http://d.pr/n/1jjoO
#include <vector>
#include <iostream>
using namespace std;

// �������� ����
// ����� ������ �������� ���������ν� �ذ��� �� �ִ�.
// => ��ü�� �߻�ȭ





class Shape
{
public:
    virtual void draw() { cout << "Shape draw" << endl; }
};

class Rect : public Shape
{
public:
    void draw() { cout << "Rect draw" << endl; }
};

class Circle : public Shape
{
public:
    void draw() { cout << "Circle draw" << endl; }
};

// ��� ������ ��üȭ�Ѵ�.
struct ICommand
{
    virtual void execute() = 0;
    virtual bool canUndo() { return false; }
    virtual void undo()    {}

    virtual ~ICommand() {}
};

class AddRectCommand : public ICommand
{
    vector<Shape*>& v;
public:
    AddRectCommand(vector<Shape*>& p) : v(p) {}

    void execute()
    {
        v.push_back(new Rect);
    }

    bool canUndo() { return true; }
    void undo()
    {
        Shape* p = v.back();
        v.pop_back();

        delete p;
    }
};

class AddCircleCommand : public ICommand
{
    vector<Shape*>& v;
public:
    AddCircleCommand(vector<Shape*>& p) : v(p) {}

    void execute()
    {
        v.push_back(new Circle);
    }

    bool canUndo() { return true; }
    void undo()
    {
        Shape* p = v.back();
        v.pop_back();

        delete p;
    }
};

class DrawCommand : public ICommand
{
    vector<Shape*>& v;
public:
    DrawCommand(vector<Shape*>& p) : v(p) {}

    void execute()
    {
        for (int i = 0; i < v.size(); ++i)
            v[i]->draw();
    }

    // �θ��� �⺻ ������ ������ �ȴ�.
    // bool canUndo() { return false; }
    // void undo()    {}
};

// http://d.pr/n/5lp0
#include <stack>
int main()
{
    vector<Shape*> v;

    stack<ICommand*> undo;
    stack<ICommand*> redo;      // 1.
    while (1)
    {
        ICommand* command = 0;

        int cmd;
        cin >> cmd;

        if (cmd == 1)      command = new AddRectCommand(v);
        else if (cmd == 2) command = new AddCircleCommand(v);
        else if (cmd == 9) command = new DrawCommand(v);
        else if (cmd == 8)
        {
            // http://d.pr/n/13SiM
            // redo ��� ����   
            command = redo.top();       // 3.
            redo.pop();
        }
        else if (cmd == 0)
        {
            // undo ��� ����.
            command = undo.top();
            undo.pop();

            command->undo();
            
            redo.push(command);         // 2.
            command = 0;
        }
        if (command != 0)
        {
            command->execute();
            if (command->canUndo())
                undo.push(command);
        }

    }
}