#include <iostream>
using namespace std;

// http://d.pr/n/1gaGz
class Mutex
{
public:
    void lock()   { cout << "mutex lock" << endl; }
    void unlock() { cout << "mutex unlock" << endl; }

    class AutoLock
    {
        Mutex& mLock;
    public:
        AutoLock(Mutex& m) : mLock(m) { mLock.lock(); }
        ~AutoLock()                   { mLock.unlock(); }
    };
};


template <typename TYPE>
class Singleton
{
protected:
    Singleton() {}

private:
    Singleton(const Singleton&);
    void operator=(const Singleton&);

    static TYPE* sInstance;
    static Mutex sLock;
public:
    static TYPE& getInstance()
    {
        Mutex::AutoLock al(sLock);
        if (sInstance == 0)
            sInstance = new TYPE;
        return *sInstance;
    }
};

template <typename TYPE>
TYPE* Singleton<TYPE>::sInstance;

template <typename TYPE>
Mutex Singleton<TYPE>::sLock;

class Cursor : public Singleton<Cursor> 
{ 
    friend class Singleton<Cursor> ;
private:
    Cursor() {}  // �ʿ��մϴ�.
};

// http://d.pr/n/wd0K
int main()
{
    // Cursor c; // �ɱ��?
    Cursor& c1 = Cursor::getInstance();
}



#if 0
class Cursor
{
private:
    Cursor() {}
    Cursor(const Cursor&);
    void operator=(const Cursor&);

    static Cursor* sInstance;
    static Mutex   sLock;
public:
    static Cursor& getInstance()
    {
        Mutex::AutoLock al(sLock);
        if (sInstance == 0)
            sInstance = new Cursor;
        return *sInstance;
    }
};

Cursor* Cursor::sInstance = 0;
Mutex   Cursor::sLock;
#endif
