// 3_LineEdit

#include <string>
#include <iostream>
using namespace std;

#include <conio.h>

class LineEdit
{
    string data;
public:
    string getData()
    {
        data.clear();

        while (1)
        {
            char c = getch();
            if (c == 13) break;

            if (isdigit(c))
            {
                data.push_back(c);
                cout << c;
            }
        }

        cout << endl;
        return data;
    }
};

// http://d.pr/n/13qwz
int main()
{
    LineEdit edit;
    while (1)
    {
        string s = edit.getData();
        cout << " > " << s << endl;
    }
}