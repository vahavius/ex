// 4_��������3
// http://d.pr/n/1eBk6
#include <string>
#include <iostream>
using namespace std;

#include <vector>
#if 0
#include <vector>
#include "tbb/cache_aligned_allocator.h"
using namespace std;
using namespace tbb;

int main()
{
    vector<int, cache_aligned_allocator<int>> v;
}
#endif


class id_traits : public char_traits<char>
{
public:
    static bool compare(const char* a, const char* b, size_t sz)
    {
        return strcmpi(a, b);
    }
};

typedef basic_string<char, id_traits> id_string;

int main()
{
    id_string s1 = "abcd";
    id_string s2 = "ABCD";

    if (s1 == s2)
        cout << "same" << endl;
    else
        cout << "not same" << endl;
}