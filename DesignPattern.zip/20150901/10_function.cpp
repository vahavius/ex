// 10_function
#include <iostream>
using namespace std;

#include <functional>   // function �̶�� ���� �Լ� ������ Ŭ������
                        // �̹� �����մϴ�.

class Dialog { public: void close() { cout << "close" << endl; } };
void foo() { cout << "foo" << endl; }

void goo(int a) { printf("goo : %d\n", a); }

void hoo(int a, int b)
{
    printf("%d %d\n", a, b);
}

using namespace std::placeholders;

void koo(int a, int b, int c, int d)
{
    printf("%d %d %d %d\n", a, b, c, d);
}

// http://d.pr/n/1jDPv
int main()
{
    function<void(int)> f = &goo;
    f(100);

    f = bind(&hoo, 20, _1);
    f(50);

    function<void(int, int)> f2 = bind(&koo, _1, _2, _2, _1);
    f2(10, 20);      // 10 20 20 10

    f2 = bind(&koo, 30, _1, _2, 10);
    f2(100, 200);    // 30, 100, 200, 10
}



#if 0
int main()
{
    function<void()> f = &foo;
    f();

    Dialog dlg;
    f = bind(&Dialog::close, &dlg);
    f();

    f = bind(&goo, 20);
    f();

}
#endif