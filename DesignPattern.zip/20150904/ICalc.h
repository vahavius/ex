// ICalc.h

class RefCountedObject
{
    int mCount;
public:
    RefCountedObject() : mCount(0) {}
    virtual ~RefCountedObject() {}

    void addRef() { ++mCount; }
    void release()
    {
        if (--mCount == 0)
            delete this;
    }
};

template <typename T>
class RefPtr
{
    T* object;
public:
    RefPtr(T* p) : object(p)
    {
        object->addRef();
    }  // ��Ģ 1.

    RefPtr(const RefPtr& p) : object(p.object)
    {
        object->addRef();
    }  // ��Ģ 2.

    ~RefPtr() { object->release(); }  // ��Ģ 3.

    // ��¥ Image ������ó�� �����ؾ� �Ѵ�. - ����Ʈ ������ �⺻
    T* operator->() { return object; }
    T& operator*()  { return *object; }
};


struct ICalc : public RefCountedObject
{
    virtual int add(int a, int b) = 0;
    virtual int sub(int a, int b) = 0;

    virtual ~ICalc() {}
};