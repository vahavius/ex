// ���� ������
class Base
{
private:
    int a;
protected:
    int b;
public:
    int c;
};


#if 0
// public
class Derived : public Base
{
protected:
    int b;
public:
    int c;
};
#endif

#if 0
// protected
class Derived : protected Base
{
// protected:
//    int b;
// protected:
//    int c;
};
#endif

// private
class Derived : private Base
{
    // private:
    //    int b;
    // private:
    //    int c;
};

// http://d.pr/n/1h4mK
int main()
{
    Base b;      b.c = 100;
    Derived d;   d.c = 100;
}