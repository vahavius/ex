// http://d.pr/n/1bZ7Q
#include <iostream>
using namespace std;

class A
{
    int a;
public:
    virtual void foo() { cout << "A foo" << endl; }  // 1
};

class B
{
    int b;
public:
    virtual void goo() { cout << "B goo" << endl; }  // 2
};

int main()
{
    A aaa;
    B* p = reinterpret_cast<B*>(&aaa);

    p->goo();
}