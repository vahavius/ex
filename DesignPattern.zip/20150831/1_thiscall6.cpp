// 1_thiscall6.cpp
// Window �� ĸ��ȭ �غ��ô�.

#include "ioacademy.h"
using namespace ioacademy;

#include <iostream>
using namespace std;

#if 0
// http://d.pr/n/19LZw
int foo(int handle, int msg, int param1, int param2)
{
    switch (msg)
    {
    case WM_LBUTTONDOWN:
        cout << "lbutton down!!" << endl;
        break;
    case WM_KEYDOWN:
        cout << "key" << endl;
        break;
    }
    return 0;
}

int main()
{
    int h1 = IoMakeWindow(foo);

    IoProcessMessage();
}
#endif

#include <map>
class Window
{
    int handle;
    static map<int, Window*> this_map;
public:
    // http://d.pr/n/1hd6G
    // ���⸦ ä��������.
    // create �Լ��� foo �Լ��� ä���� �մϴ�. (Clock)
    void create()
    {
        handle = IoMakeWindow(foo);
        this_map[handle] = this;
    }

    static int foo(int handle, int msg, int param1, int param2)
    {
        Window* self = this_map[handle];
        switch (msg)
        {
        case WM_LBUTTONDOWN:
            self->onLButtonDown(); break;
        case WM_KEYDOWN:
            self->onKeyDown(); break;
        }
        return 0;
    }

    virtual void onLButtonDown() {}
    virtual void onKeyDown() {}
};

map<int, Window*> Window::this_map;



class MyWindow : public Window
{
public:
    virtual void onLButtonDown()
    { cout << "lbutton" << endl; }

    virtual void onKeyDown()
    { cout << "key" << endl; }
};

int main()
{
    MyWindow w;
    w.create();   // �̼��� �����찡 ��������� �մϴ�.
                  // ���� ��ư�� ������ "lbutton" �� ��µǾ�� �մϴ�.

    IoProcessMessage();
}