// 2_ĳ����2
// Inside C++ Object - 1998��(���ĸ� ����)

#include <iostream>
using namespace std;

class X { public: int x; };
class Y { public: int y; };

class C : public X, public Y
{
public:
    int c;
};

// http://d.pr/n/1bFa9
int main()
{
    C ccc;
    cout << &ccc << endl;   // 100 ������� �����սô�.
    
    X* px = &ccc;
    cout << px << endl;

    Y* py = reinterpret_cast<Y*>(&ccc);
    // Y* py = static_cast<Y*>(&ccc);  // 100
    cout << py << endl;   // 104

    py->y = 10;

    cout << ccc.x << endl;
    cout << ccc.y << endl;
}