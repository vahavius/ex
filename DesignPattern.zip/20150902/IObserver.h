struct IObserver
{
public:
    virtual void onUpdate(void* data) = 0;
    virtual ~IObserver() {}
};