// 8_������3
// http://d.pr/n/t3uN       - 2
// http://d.pr/n/1l1rp      - 3
// http://d.pr/n/13RZJ      - SampleGraph.cpp
// http://d.pr/f/g1Nx       - SampleGraph.dll
#include <vector>
#include <iostream>
using namespace std;

#include "ioacademy.h"
using namespace ioacademy;

#include "IObserver.h"

class Subject
{
    vector< IObserver* > v;
public:
    Subject()
    {
        // ��ӵ� ������ ��� DLL�� �����Ѵ�.
        IoEnumFiles("D:\\PlugIn", "*.dll", LoadModule, this);
    }
    // http://d.pr/n/Ed8d
    // �Ʒ� �Լ��� �� static �̾�� �ϴ��� ��Ȯ�� �Ƽž� �մϴ�.
    static int LoadModule(string name, void* param)
    {
        cout << name << endl;
        // 1. DLL Load
        void* addr = IoLoadModule(name);   // dlopen

        // 2. ��ӵ� �Լ��� ã�´�.
        typedef IObserver*(*FP)();
        FP f = (FP)IoGetFunctionAddress(addr, "CreateGraph");

        // 3. �׷��� ����
        IObserver* p = f();

        // this �� ������ ���.
        Subject* self = static_cast<Subject*>(param);
        self->attach(p);

        return 1;
    }



    void attach(IObserver* p) { v.push_back(p); }
    void detach(IObserver* p) {}

    void notify(void *p)
    {
        for (int i = 0; i < v.size(); ++i)
            v[i]->onUpdate(p);
    }
};

class Table : public Subject
{
    int data[5];
public:
    Table() { memset(data, 0, sizeof(data)); }

    void edit()
    {
        while (1)
        {
            int index;
            cout << "index : "; cin >> index;
            cout << "data : ";  cin >> data[index];

            // ��� �����ڿ��� �˷��ش�.
            notify(data);
        }
    }
};

//--------------------------------------
class PieGraph : public IObserver
{
public:
    void onUpdate(void* p)
    {
        int* data = static_cast<int*>(p);

        cout << "****** Pie Graph ******" << endl;
        for (int i = 0; i < 5; i++)
            cout << i << " : " << data[i] << endl;
    }
};

class BarGraph : public IObserver
{
public:
    void onUpdate(void* p)
    {
        int* data = static_cast<int*>(p);

        cout << "****** Bar Graph ******" << endl;
        for (int i = 0; i < 5; i++)
            cout << i << " : " << data[i] << endl;
    }
};

int main()
{
    Table table;
    BarGraph g1; PieGraph g2;

    table.attach(&g1);
    table.attach(&g2);

    table.edit();
}

// http://d.pr/f/12Z83