/*
 * Airline.cpp
 *
 *  Created on: 2014. 4. 28.
 *      Author: hyunsangyoun
 */

#include "Airline.h"

Airline::Airline() {}

Airline::~Airline() {}

bool Airline::reserve(std::string place){
	return true;
}
