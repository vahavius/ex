/*
 * Hotel.cpp
 *
 *  Created on: 2014. 4. 28.
 *      Author: hyunsangyoun
 */

#include "Hotel.h"

Hotel::Hotel() {}

Hotel::~Hotel() {}

bool Hotel::reserve(std::string place){
	return true;
}

