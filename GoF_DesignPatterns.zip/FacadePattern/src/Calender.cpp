/*
 * Calender.cpp
 *
 *  Created on: 2014. 4. 28.
 *      Author: hyunsangyoun
 */

#include "Calender.h"

Calender::Calender() {}

Calender::~Calender() {}

bool Calender::changeSchedule(std::string place, bool ASAP){
	return true;
}
