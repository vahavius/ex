/*
 * Main.cpp
 *
 *  Created on: 2014. 4. 14.
 *      Author: hyunsangyoun
 */

#include "Singleton.h"
int main(){
	Singleton* s = Singleton::getInstance();
}

