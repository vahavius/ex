/*
 * Strategy.cpp
 *
 *  Created on: 2014. 4. 14.
 *      Author: hyunsangyoun
 */

#include "Strategy.h"

namespace std {

Strategy::Strategy() {}

Strategy::~Strategy() {}

} /* namespace std */
