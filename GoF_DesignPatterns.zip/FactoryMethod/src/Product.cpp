/*
 * Product.cpp
 *
 *  Created on: 2014. 4. 16.
 *      Author: hyunsangyoun
 */

#include "Product.h"
#include <string>
namespace std {

Product::Product(string owner) {}

Product::~Product() {}

void Product::use() {}

} /* namespace std */
