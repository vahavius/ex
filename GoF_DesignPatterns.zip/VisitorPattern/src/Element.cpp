/*
 * Element.cpp
 *
 *  Created on: 2014. 5. 19.
 *      Author: hyunsangyoun
 */

#include "Element.h"

Element::Element() {}

Element::~Element() {}
