/*
 * AbstractProductA.h
 *
 *  Created on: 2014. 5. 14.
 *      Author: hyunsangyoun
 */

#ifndef ABSTRACTPRODUCTA_H_
#define ABSTRACTPRODUCTA_H_

class AbstractProductA {
public:
	AbstractProductA();
	virtual ~AbstractProductA();
	virtual void useProductA();
};

#endif /* ABSTRACTPRODUCTA_H_ */
