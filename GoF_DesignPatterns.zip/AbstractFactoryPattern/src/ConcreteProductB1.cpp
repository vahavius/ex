/*
 * ConcreteProductB1.cpp
 *
 *  Created on: 2014. 5. 14.
 *      Author: hyunsangyoun
 */

#include "ConcreteProductB1.h"
#include <iostream>

ConcreteProductB1::ConcreteProductB1() {}

ConcreteProductB1::~ConcreteProductB1() {}

void ConcreteProductB1::useProductB(){
	std::cout << "use Product B1" << std::endl;
}
