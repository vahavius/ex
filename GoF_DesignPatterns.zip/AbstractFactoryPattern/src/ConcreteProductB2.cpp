/*
 * ConcreteProductB2.cpp
 *
 *  Created on: 2014. 5. 14.
 *      Author: hyunsangyoun
 */

#include "ConcreteProductB2.h"
#include <iostream>

ConcreteProductB2::ConcreteProductB2() {}

ConcreteProductB2::~ConcreteProductB2() {}

void ConcreteProductB2::useProductB(){
	std::cout << "use Product B2" << std::endl;
}
