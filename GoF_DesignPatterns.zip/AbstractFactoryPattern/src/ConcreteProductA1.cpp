/*
 * ConcreteProductA1.cpp
 *
 *  Created on: 2014. 5. 14.
 *      Author: hyunsangyoun
 */

#include "ConcreteProductA1.h"
#include <iostream>

ConcreteProductA1::ConcreteProductA1() {}

ConcreteProductA1::~ConcreteProductA1() {}

void ConcreteProductA1::useProductA() {
	std::cout << "use Product A1" << std::endl;
}
