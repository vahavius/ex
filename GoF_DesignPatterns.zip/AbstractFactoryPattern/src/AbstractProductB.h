/*
 * AbstractProductB.h
 *
 *  Created on: 2014. 5. 14.
 *      Author: hyunsangyoun
 */

#ifndef ABSTRACTPRODUCTB_H_
#define ABSTRACTPRODUCTB_H_

class AbstractProductB {
public:
	AbstractProductB();
	virtual ~AbstractProductB();
	virtual void useProductB();
};

#endif /* ABSTRACTPRODUCTB_H_ */
