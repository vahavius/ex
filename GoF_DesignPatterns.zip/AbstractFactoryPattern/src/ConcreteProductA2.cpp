/*
 * ConcreteProductA2.cpp
 *
 *  Created on: 2014. 5. 14.
 *      Author: hyunsangyoun
 */

#include "ConcreteProductA2.h"
#include <iostream>

ConcreteProductA2::ConcreteProductA2() {}

ConcreteProductA2::~ConcreteProductA2() {}

void ConcreteProductA2::useProductA() {
	std::cout << "use Product A2" << std::endl;
}
