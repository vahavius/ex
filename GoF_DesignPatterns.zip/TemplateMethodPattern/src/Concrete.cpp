/*
 * Concrete1.cpp
 *
 *  Created on: 2014. 4. 15.
 *      Author: hyunsangyoun
 */

#include "Concrete.h"
#include <iostream>
namespace std {

Concrete::Concrete() {}

Concrete::~Concrete() {}

void Concrete::process1(){
	cout << "process1" << endl;
}

void Concrete::process2(){
	cout << "process2" << endl;
}

void Concrete::process3(){
	cout << "process3" << endl;
}

} /* namespace std */
