/*
 * Poster.cpp
 *
 *  Created on: 2014. 4. 23.
 *      Author: hyunsangyoun
 */

#include "Poster.h"

namespace std {
Poster::Poster() {}
Poster::~Poster() {}
} /* namespace std */
