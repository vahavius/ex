/*
 * Receiver.h
 *
 *  Created on: 2014. 5. 12.
 *      Author: hyunsangyoun
 */

#ifndef RECEIVER_H_
#define RECEIVER_H_

class Receiver {
public:
	Receiver();
	virtual ~Receiver();
	void action();
};

#endif /* RECEIVER_H_ */
