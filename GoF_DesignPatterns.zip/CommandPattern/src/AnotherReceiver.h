/*
 * AnotherReceiver.h
 *
 *  Created on: 2014. 5. 13.
 *      Author: hyunsangyoun
 */

#ifndef ANOTHERRECEIVER_H_
#define ANOTHERRECEIVER_H_

class AnotherReceiver {
public:
	AnotherReceiver();
	virtual ~AnotherReceiver();
	void func1();
	void func2();
	void func3();
};

#endif /* ANOTHERRECEIVER_H_ */
