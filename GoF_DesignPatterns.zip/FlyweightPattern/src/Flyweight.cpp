/*
 * Flyweight.cpp
 *
 *  Created on: 2014. 5. 6.
 *      Author: wizehack
 */

#include "Flyweight.h"
Flyweight::Flyweight() {}

Flyweight::~Flyweight() {}
